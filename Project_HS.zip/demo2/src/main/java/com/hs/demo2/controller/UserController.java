package com.hs.demo2.controller;

import com.hs.demo2.domain.User;
import com.hs.demo2.service.UserService;
import org.apache.ibatis.annotations.Select;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Description:
 *
 * @author ChenJunDong
 * @version 1.0.0
 */
//控制器类
@RestController
//配置此模块公共映射
@RequestMapping("/users")
public class UserController {


    @Autowired
    private UserService userService;

    @PostMapping
    public Result save(@RequestBody User user) {
    boolean flag = userService.save(user);
    return new Result(flag ? Code.SAVE_OK:Code.SAVE_ERR,flag);
}

    @PutMapping
    public Result update(@RequestBody User user) {
        boolean flag = userService.update(user);
        return new Result(flag ? Code.UPDATE_OK:Code.UPDATE_ERR,flag);
    }

    @DeleteMapping("/{id}")
    public Result delete(@PathVariable Integer id) {
        boolean flag = userService.delete(id);
        return new Result(flag ? Code.DELETE_OK:Code.DELETE_ERR,flag);
    }

    @GetMapping("/{id}")
    public Result getById(@PathVariable Integer id) {
        User user = userService.getById(id);
        Integer code = user != null ? Code.GET_OK : Code.GET_ERR;
        String msg = user != null ? "" : "数据查询失败，请重试！";
        return new Result(code,user,msg);
    }

    @GetMapping
    public Result getAll() {
        System.out.println("数据查询成功！");
        List<User> userList = userService.getAll();
        Integer code = userList != null ? Code.GET_OK : Code.GET_ERR;
        String msg = userList != null ? "" : "数据查询失败，请重试！";
        return new Result(code,userList,msg);
    }

    @PostMapping(value = "/login")
    public Result login(@RequestBody User user){
        System.out.println(user);
        System.out.println("登录用户查询");
        boolean flag = userService.login(user);
        return new Result(flag ? Code.GET_OK:Code.GET_ERR,flag);
    }
}



//    @PostMapping
//    public boolean save(@RequestBody User user) {
//        return userService.save(user);
//    }
//
//    @PutMapping
//    public boolean update(@RequestBody User user) {
//        return userService.update(user);
//    }
//
//    @DeleteMapping("/{id}")
//    public boolean delete(@PathVariable Integer id) {
//        return userService.delete(id);
//    }
//
//    @GetMapping("/{id}")
//    public User getById(@PathVariable Integer id) {
//        return userService.getById(id);
//    }
//
//    @GetMapping
//    public List<User> getAll() {
//        return userService.getAll();
//    }
