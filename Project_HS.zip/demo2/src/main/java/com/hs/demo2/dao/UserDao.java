package com.hs.demo2.dao;

import com.hs.demo2.domain.User;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * Description:
 *
 * @author ChenJunDong
 * @version 1.0.0
 */

@Mapper
public interface UserDao {

    @Insert("insert into tab_users (username,password) values(#{username},#{password})")
    public int save(User user);

    @Update("update tab_users set username = #{username}, password = #{password} where id = #{id}")
    public int update(User user);

    @Delete("delete from tab_users where id = #{id}")
    public int delete(Integer id);

    @Select("select * from tab_users where id = #{id}")
    public User getById(Integer id);

    @Select("select * from tab_users")
    public List<User> getAll();

    @Select("select id from tab_users where username=#{username} and password = #{password}")
//    public User login(String username,String password);
    public User login(User user);
}
