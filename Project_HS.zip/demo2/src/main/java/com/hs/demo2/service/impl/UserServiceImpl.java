package com.hs.demo2.service.impl;

import com.hs.demo2.dao.UserDao;
import com.hs.demo2.domain.User;
import com.hs.demo2.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Description:
 *
 * @author ChenJunDong
 * @version 1.0.0
 */

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserDao userDao;

    public boolean save(User user) {
        userDao.save(user);
        return true;
    }

    public boolean update(User user) {
        userDao.update(user);
        return true;
    }

    public boolean delete(Integer id) {
        userDao.delete(id);
        return true;
    }

    public User getById(Integer id) {
        return userDao.getById(id);
    }

    public List<User> getAll() {
        return userDao.getAll();
    }

    public boolean login(User user) {
        boolean FLAG=false;
        if(userDao.login(user)!=null){
            FLAG = true;
        }
        else {
            FLAG=false;
        }
        return  FLAG;
    }
}
