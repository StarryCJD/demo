package com.hs.demo2.service;

import com.hs.demo2.domain.User;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * Description:
 *
 * @author ChenJunDong
 * @version 1.0.0
 */

public interface UserService {
    public boolean save(User user);

    public boolean update(User user);

    public boolean delete(Integer id);

    public User getById(Integer id);

    public List<User> getAll();

    public boolean login(User user);

}
