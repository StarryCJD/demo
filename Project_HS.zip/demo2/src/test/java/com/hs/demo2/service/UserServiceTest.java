package com.hs.demo2.service;

import com.hs.demo2.domain.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;


/**
 * Description:
 *
 * @author ChenJunDong
 * @version 1.0.0
 */

@SpringBootTest
public class UserServiceTest {

    @Autowired
    private UserService userService;

    @Test
    void save() {
    }

    @Test
    void update() {
    }

    @Test
    void delete() {
    }

    @Test
    void getById() {
        User user = userService.getById(1);
        System.out.println(user);
    }

    @Test
    void getAll() {
       List<User> all = userService.getAll();
        System.out.println(all);
    }

    @Test
    void login(){
        User userTemp=new User();
        userTemp.setUsername("Kudo Sara");
        userTemp.setPassword("WUq6NntDd");
        boolean flag=userService.login(userTemp);
        System.out.println(flag);

    }
}