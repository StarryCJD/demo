/*
 Navicat Premium Data Transfer

 Source Server         : MySQL
 Source Server Type    : MySQL
 Source Server Version : 80029
 Source Host           : localhost:3306
 Source Schema         : hs_demo1_db

 Target Server Type    : MySQL
 Target Server Version : 80029
 File Encoding         : 65001

 Date: 16/11/2022 10:48:52
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tab_users
-- ----------------------------
DROP TABLE IF EXISTS `tab_users`;
CREATE TABLE `tab_users`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 52 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tab_users
-- ----------------------------
INSERT INTO `tab_users` VALUES (1, 'Kudo Sara', 'WUq6NntDd');
INSERT INTO `tab_users` VALUES (2, 'Ono Rin', 'TGKwLt833b');
INSERT INTO `tab_users` VALUES (3, 'Lok Ka Ling', 'MA5o5l87Ik');
INSERT INTO `tab_users` VALUES (4, 'Emily Walker', 'sJuF1nJ4g7');
INSERT INTO `tab_users` VALUES (5, 'Carrie Rivera', 'ffpS08OJmV');
INSERT INTO `tab_users` VALUES (6, 'Wang Zitao', 'KrNiY02Ual');
INSERT INTO `tab_users` VALUES (7, 'Aoki Nanami', 'uGBozRTxiR');
INSERT INTO `tab_users` VALUES (8, 'Tang Lik Sun', 'xDLYZk88Ze');
INSERT INTO `tab_users` VALUES (9, 'Sheh Yun Fat', 'kUG6Dopsv3');
INSERT INTO `tab_users` VALUES (10, 'Maria Sanchez', 'JNp8XDHTWY');
INSERT INTO `tab_users` VALUES (11, 'Xia Zhennan', 'xozTw2yZit');
INSERT INTO `tab_users` VALUES (12, 'Lau Kwok Wing', 'cl8JVBBVqh');
INSERT INTO `tab_users` VALUES (13, 'Yang Lu', 'o3WRdPdXtL');
INSERT INTO `tab_users` VALUES (14, 'Chung Kwok Yin', 'n6hDSku8JT');
INSERT INTO `tab_users` VALUES (15, 'Sarah Jackson', 'njfg5CE8WO');
INSERT INTO `tab_users` VALUES (16, 'Mao Zhennan', 'rzsl5xtR4a');
INSERT INTO `tab_users` VALUES (17, 'Shing Ling Ling', 'WwOx1yVhGH');
INSERT INTO `tab_users` VALUES (18, 'Katherine Howard', 'UcyOYtXEpH');
INSERT INTO `tab_users` VALUES (19, 'Joan Evans', '0txwkQAALc');
INSERT INTO `tab_users` VALUES (20, 'Donna Freeman', 'hRPOcFtpo6');
INSERT INTO `tab_users` VALUES (21, 'Yuen Kwok Wing', 'TYVodH75LC');
INSERT INTO `tab_users` VALUES (22, 'Otsuka Kenta', 'MToIww67ca');
INSERT INTO `tab_users` VALUES (23, 'Imai Ikki', 'ccS5oX0viO');
INSERT INTO `tab_users` VALUES (24, 'Fung Ling Ling', 'yatqPTPFj4');
INSERT INTO `tab_users` VALUES (25, 'Russell Wilson', 'wLcae3yIum');
INSERT INTO `tab_users` VALUES (26, 'Gary Alvarez', 'BzZNCegWZX');
INSERT INTO `tab_users` VALUES (27, 'Ma Ka Fai', 'mmHySZVXNW');
INSERT INTO `tab_users` VALUES (28, 'Kono Hina', 'hcoIKQUjv1');
INSERT INTO `tab_users` VALUES (29, 'Yokoyama Misaki', 'TJUqBDfrws');
INSERT INTO `tab_users` VALUES (30, 'Joel Williams', '6EYjbgnEWH');
INSERT INTO `tab_users` VALUES (31, 'Herbert Castillo', 'Lpy0pHTRcv');
INSERT INTO `tab_users` VALUES (32, 'Ellen Crawford', 'jXS3JL6N2p');
INSERT INTO `tab_users` VALUES (33, 'Lui Ka Man', 'hahly1URIy');
INSERT INTO `tab_users` VALUES (34, 'Nishimura Hazuki', 'ks9Ofr2luC');
INSERT INTO `tab_users` VALUES (35, 'Cheng Yun Fat', 'H2UZUuMx55');
INSERT INTO `tab_users` VALUES (36, 'Yung Sai Wing', 'mNPQAX0lx7');
INSERT INTO `tab_users` VALUES (37, 'Pak Chi Ming', 'gerJbz0bpf');
INSERT INTO `tab_users` VALUES (38, 'Zeng Yunxi', 'rPDUdMuEw2');
INSERT INTO `tab_users` VALUES (39, 'Lillian Cole', 'ZpHKc7jmIy');
INSERT INTO `tab_users` VALUES (40, 'Sun Zhiyuan', 'EOnIpGXbCe');
INSERT INTO `tab_users` VALUES (41, 'Au Ming Sze', 'BcwTbiTdlw');
INSERT INTO `tab_users` VALUES (42, 'Xia Yuning', 'NwTygiZTPP');
INSERT INTO `tab_users` VALUES (43, 'Rebecca Barnes', '4AOzIE5dNR');
INSERT INTO `tab_users` VALUES (44, 'Yokoyama Miu', 'ofomnGcDqu');
INSERT INTO `tab_users` VALUES (45, 'Hashimoto Hikaru', 'TKlxVYZPfT');
INSERT INTO `tab_users` VALUES (46, 'Nomura Rena', 'Cy1dClvbeQ');
INSERT INTO `tab_users` VALUES (47, 'Jesse Gonzales', '6FuVpxZWa4');
INSERT INTO `tab_users` VALUES (48, 'Ishida Rena', 'LRHzKFL0iA');
INSERT INTO `tab_users` VALUES (49, 'Shi Xiuying', '9leDXiVQjU');
INSERT INTO `tab_users` VALUES (50, 'dsfg', 'fsd');
INSERT INTO `tab_users` VALUES (51, '3245', '1234');

SET FOREIGN_KEY_CHECKS = 1;
